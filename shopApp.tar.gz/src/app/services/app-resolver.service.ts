import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { of } from 'rxjs';
import { Product } from '../components/products/product';


@Injectable({
  providedIn: 'root'
})

export class AppResolver implements Resolve<any> {

  products: Product[] = [
    { id: 1, name: "Asus Laptop", price: 3000,categoryId: 1, description: "i7 8b 500gb hdd 2 gb nvidia", count: 0, src: "/assets/images/laptop.jpeg" },
    { id: 2, name: "Logitech Mouse", price: 100, categoryId: 2, description: "1600 dpi game mouse", count: 0, src: "/assets/images/mouse.jpg" },
    { id: 3, name: "Led Tv", price: 5000, categoryId: 3, description: "43 inch",  count: 0, src: "/assets/images/tv.jpg" },
    { id: 4, name: "Orhan Pamuk", price: 30, categoryId: 4, description: "Masumiyet Müzesi",  count: 0, src: "/assets/images/orhan.jpg" },
    { id: 5, name: "Apple Iphone X", price: 10000, categoryId: 5, description: "128 gb",  count: 0, src: "/assets/images/586.jpg" }
  ]

constructor() { }
  resolve(route: ActivatedRouteSnapshot) {
   const categoryId = route.params.id
   return   of(this.products.filter(item => item.categoryId == categoryId))
  }

}
