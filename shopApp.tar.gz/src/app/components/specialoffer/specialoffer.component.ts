import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-specialoffer',
  templateUrl: './specialoffer.component.html',
  styleUrls: ['./specialoffer.component.css']
})
export class SpecialofferComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
