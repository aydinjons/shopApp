export class Product{
    id:number;
    name:string;
    price:number;
    categoryId:number;
    description:string;
    src:string;
    count:number;
}

