export class Image{
    id:number;
    url:string;
    header:string;
    description;
}