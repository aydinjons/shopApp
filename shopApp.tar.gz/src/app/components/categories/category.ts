
export class category{
    id:number;
    name:string;
    categoryId:number;
}